// public/js/client.js

let cityInput = document.querySelector("#cityInput");
let submitBtn = (document.querySelector(".submitBtn").onclick =
  async function () {
    localStorage.setItem("cityName", cityInput.value);
    location.reload();
  });

let cityLocal = localStorage.getItem("cityName");
let cities = cityLocal ? [cityLocal] : [];

var map = L.map("map").setView([40.7128, -74.006], 13);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap contributors",
}).addTo(map);

async function fetchExtendedForecast(cityName) {
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${cityName}&appid=e406e06719ce3021bfaac41c3433e219&units=metric`
    );

    if (!response.ok) {
      throw new Error("Unable to fetch extended forecast data.");
    }

    const responseData = await response.json();
    // Return all forecast data
    return responseData.list;
  } catch (error) {
    console.error("Error fetching extended forecast:", error);
    return null;
  }
}

async function addCityMarkers(cityNames) {
  const markers = [];

  for (const cityName of cityNames) {
    try {
      const response = await fetch(
        `https://api.opencagedata.com/geocode/v1/json?q=${cityName}&key=aa857c29c2ba4be39b639ac7033c0f3b`
      );
      const responseData = await response.json();

      const { lat, lng } = responseData.results[0].geometry;

      const marker = L.marker([lat, lng]).addTo(map);
      marker.bindPopup(cityName);
      markers.push(marker);

      const extendedForecast = await fetchExtendedForecast(cityName);

      if (extendedForecast) {
        displayExtendedForecast(extendedForecast.slice(0, 14)); // Display the first 14 days
      }
    } catch (error) {
      console.error(`Error processing city ${cityName}:`, error);
    }
  }

  if (markers.length > 0) {
    const group = new L.featureGroup(markers);
    map.fitBounds(group.getBounds());
  }
}

async function displayExtendedForecast(extendedForecast) {
  const forecastContainer = document.getElementById("forecastContainer");
  forecastContainer.innerHTML = ""; // Clear previous content

  const uniqueDates = new Set();
  let count = 0;

  for (const forecast of extendedForecast) {
    const date = new Date(forecast.dt * 1000);
    const formattedDate = date.toDateString();
    if (uniqueDates.has(formattedDate)) {
      continue;
    }
    uniqueDates.add(formattedDate);
    const forecastHTML = `
      <div class="forecast-entry">
        <p>Date: ${formattedDate}</p>
        <p>Max Temperature: ${forecast.main.temp_max}°C</p>
        <p>Min Temperature: ${forecast.main.temp_min}°C</p>
        <p>Wind Direction: ${forecast.wind.deg}°</p>
      </div>
    `;
    forecastContainer.innerHTML += forecastHTML;
    count++;
    if (count === 7) {
      break;
    }
  }
}

addCityMarkers(cities);
